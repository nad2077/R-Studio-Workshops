# A script printing hello world
print('Hello world!')

