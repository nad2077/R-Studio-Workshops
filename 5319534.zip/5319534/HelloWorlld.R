# A script printing hello world
print('Hello world!')
# i am sjfbse