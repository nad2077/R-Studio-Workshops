sentence <- c('By','the','time','they', 'got', 'back,', 'the', 'lights', 'were', 'all', 'out', 'and', 'everybody', 'was', 'asleep.', 'Everybody,', 'that', 'is,', 'except', 'for', 'Guih', 'Kyom', 'the', 'dung', 'beetle.', 'He', 'was', 'wide', 'awake', 'and', 'on', 'duty,', 'lying', 'on', 'his', 'back', 'with', 'his', 'legs', 'in', 'the', 'air', 'to', 'save', 'the', 'world', 'in', 'case', 'the', 'heavens', 'fell.')

grep_out <- grep(pattern = 'the', x = sentence)
grep_out <-  grep("in", c("gremlin", "goblin", "kremlin")) # output 1, 2 ,3
grep_out

grepp_out <- grep(pattern = '[A-Z]', x = sentence)
grepp_out
sentence[grepp_out]

#use the special character '.' 
#to specify that any character can match the search pattern
grep_out <- grep(pattern = 'a.e', x = sentence)
sentence[grep_out]

#quantifiers
#allow the user to specify how many of a character (or set of characters) 
#grep() is matching to. The three main symbols are ‘?’, ‘*’ and ‘+’
#? is 0-1
#* is 0 or more
#+ is 1 or more

sentence[grep(pattern = 'e.?e', x = sentence)]
sentence[grep(pattern = 'e.+e', x = sentence)]

#'gsub()' function can be used to search for text in the same way as the 'grep()' function,
#' but instead of finding the instances of our search term,
#'  it instead substitutes the matched text with text of our choosing.

gsub_out <- gsub(pattern = 'a.e', x = sentence, replacement = '!!!')
gsub_out

#1
species_names <- colnames(dung_beetles)
species_names
species <- species_names[3:81]
species

#3
cspecies <- species[grep(pattern = 'C', x = species)]
cspecies

#3
rspeceis <-species[grep(pattern = '_r', x = species)]
rspeceis

#5
tg <- species[grep(pattern = 'Copis', x = species)]
tg

#6
dg <- species[grep(pattern = 'Microcopis', x = species)]
dg
grep_out

x <- 'Microcopris'
match(x, species)
species[74
gsub_out <- gsub(pattern = 'Microcopis', x = species, replacement = 'Microcopris')
gsub_out
grep_out[grep(pattern = 'Microcopis', x = grep_out)]

er <-species[grep(pattern = 'Micro', x = species)]
er

i <- 1

for(t in 1:4) {
  
  i <- 3*i-1
  print(i)
}

3*3*3
9*9*9
11*11*11
10 %% 2
12*12*12


class(dung_beetles)

bt <- read_csv("dung_beetles.csv")
nm <- colnames(bt[1:81])
nm

cn <- grep(pattern = '^C', x = nm)
nm[cn]

sn <- grep(pattern = '.+_r', x = nm)
nm[sn]


con <- gsub(pattern = 'Copis', x = nm, replacement = "Copris")
con

mic <- gsub(pattern = 'Microcopis', x = nm, replacement = 'Microcopris')
mic

chaq <- grep(pattern = '^O.+s$', x = nm)
nm[chaq]

gty <- gsub(pattern = 'opis', x =nm, replacement = 'opris')
gty

colnames(bt) <- gty
bt

bt[ bt$Month = '$y']
th <- grep(pattern = '$y', x = bt[2,])
tg <- grep(pattern = '^O', x = colnames(bt))
bt[th]
bt[,2]

dfe <- nyt[ nyt$best_rank ==1 & nchar(nyt$title) <15,]

